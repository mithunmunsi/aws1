# aws1

## Deploy the application using AWS Elastic Beanstack and use AWS Codepipeline
